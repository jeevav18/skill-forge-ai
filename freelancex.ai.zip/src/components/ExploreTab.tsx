import React, { useState } from "react";
import { Search, MapPin, Briefcase, Award, Star, BookOpen, MessageSquare, ArrowUpRight, CheckCircle, Flame, Target, Sparkles, Building, Zap, Lock, Unlock, ShieldAlert, Check, HelpCircle } from "lucide-react";
import { Freelancer, Job, Company, TechnologyCardInfo } from "../types";
import { TECH_DOMAINS, TECHNOLOGY_CARDS, SALESFORCE_CERTIFICATIONS, MOCK_CHALLENGES } from "../data";

interface ExploreTabProps {
  freelancers: Freelancer[];
  jobs: Job[];
  companies: Company[];
  onSelectFreelancer: (freelancer: Freelancer) => void;
  onSelectJob: (job: Job) => void;
  currency: "USD" | "INR";
  selectedDomain?: string;
  setSelectedDomain?: (domain: string) => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  isLoggedIn?: boolean;
}

export default function ExploreTab({ 
  freelancers, 
  jobs, 
  companies, 
  onSelectFreelancer, 
  onSelectJob, 
  currency,
  selectedDomain: propSelectedDomain,
  setSelectedDomain: propSetSelectedDomain,
  searchQuery: propSearchQuery,
  setSearchQuery: propSetSearchQuery,
  isLoggedIn = false
}: ExploreTabProps) {
  const [localSelectedDomain, localSetSelectedDomain] = useState<string>("all");
  const selectedDomain = propSelectedDomain !== undefined ? propSelectedDomain : localSelectedDomain;
  const setSelectedDomain = propSetSelectedDomain !== undefined ? propSetSelectedDomain : localSetSelectedDomain;

  const [localSearchQuery, localSetSearchQuery] = useState("");
  const searchQuery = propSearchQuery !== undefined ? propSearchQuery : localSearchQuery;
  const setSearchQuery = propSetSearchQuery !== undefined ? propSetSearchQuery : localSetSearchQuery;
  const [selectedTechCard, setSelectedTechCard] = useState<TechnologyCardInfo | null>(TECHNOLOGY_CARDS[0]);
  const [bidModalOpen, setBidModalOpen] = useState(false);
  const [activeJobForBid, setActiveJobForBid] = useState<Job | null>(null);
  const [bidAmount, setBidAmount] = useState("");
  const [bidProposal, setBidProposal] = useState("");
  const [bidSuccess, setBidSuccess] = useState(false);
  const [selectedMncTier, setSelectedMncTier] = useState<"all" | 1 | 2 | 3>("all");
  const [selectedMncPartner, setSelectedMncPartner] = useState<any | null>(null);
  const [enrollSuccessMessage, setEnrollSuccessMessage] = useState("");
  const [customEnrollFields, setCustomEnrollFields] = useState({ portfolioUrl: "", verifiedBadgeChecked: true, agreeToSponsorTandC: true });

  const formatStringRate = (rateStr: string) => {
    if (currency === "USD") {
      if (rateStr.includes("₹")) {
        return rateStr.replace(/₹([\d,]+)/g, (match, p1) => {
          const inr = parseInt(p1.replace(/,/g, ""), 10);
          return "$" + Math.round(inr / 83).toLocaleString("en-US");
        });
      }
      return rateStr;
    } else {
      if (rateStr.includes("$")) {
        return rateStr.replace(/\$([\d,]+)/g, (match, p1) => {
          const usd = parseInt(p1.replace(/,/g, ""), 10);
          return "₹" + Math.round(usd * 83).toLocaleString("en-IN");
        });
      }
      return rateStr;
    }
  };

  const MNC_PARTNERS = [
    { 
      name: "Google Cloud", 
      tier: 1, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/5/51/Google_Cloud_logo.svg", 
      role: "Strategic AI Infrastructure Partner", 
      packageRange: "₹2,400,000 - ₹4,800,000/yr", 
      activeContracts: 32, 
      hq: "Mountain View, USA (Multiple Indian Hubs)",
      roles: ["GenAI Platform Architect", "Cloud Systems Kubernetes Specialist", "Advanced Data Engineer"],
      reqs: [
        "Core performance rendering rules & high-density node optimization",
        "Google Cloud Machine Learning / Professional Cloud Dev Certified",
        "System design evaluation benchmark of >= 85% on SkillForge mock nodes",
        "No unresolved security discrepancies in background verification registry"
      ],
      prepSubject: "Generative AI LLM Specialist",
      dsaScore: 85,
      certifications: ["Google Cloud ML Engineer", "Kubernetes Certified Admin"]
    },
    { 
      name: "Salesforce Systems", 
      tier: 1, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg", 
      role: "Direct CRM Integration Sponsor", 
      packageRange: "₹2,200,000 - ₹4,500,000/yr", 
      activeContracts: 45, 
      hq: "San Francisco, USA (Bangalore Hub)",
      roles: ["Salesforce LWC Developer", "Revenue Cloud (CPQ) Consultant", "Apex Governor Limit Auditor"],
      reqs: [
        "Bulkification trigger logic avoiding query execution within loop blocks",
        "Salesforce Certified Platform Developer II or CTA certificate",
        "Interactive mock interview performance score >= 85% on Salesforce prep",
        "Clean verified status on the digital credentials tracking ledger"
      ],
      prepSubject: "Salesforce LWC & Apex",
      dsaScore: 85,
      certifications: ["PDII", "CTA Architect", "Revenue Cloud Consultant"]
    },
    { 
      name: "Microsoft Corporation", 
      tier: 1, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/9/96/Microsoft_logo_edge_version_%282012-present%29.svg", 
      role: "Developer Tools Integration", 
      packageRange: "₹2,500,000 - ₹5,000,000/yr", 
      activeContracts: 28, 
      hq: "Redmond, USA (Hyderabad HQ)",
      roles: ["Azure Cloud Integrator", "TypeScript compiler optimization Specialist", "DevOps Pipeline Engineer"],
      reqs: [
        "Strong experience with strict type interfaces and build optimization hooks",
        "Microsoft Certified Azure Solutions Architect",
        "Core coding simulation speed & accuracy test score >= 85%",
        "Active GitHub integration verified badges showing profile quality"
      ],
      prepSubject: "React Frontend Developer",
      dsaScore: 85,
      certifications: ["Azure Solutions Architect", "GitHub Actions Pro"]
    },
    { 
      name: "Accenture Enterprise", 
      tier: 1, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/c/cd/Accenture.svg", 
      role: "Global Delivery Integrator", 
      packageRange: "₹1,800,000 - ₹3,600,000/yr", 
      activeContracts: 110, 
      hq: "Dublin, Ireland (Bangalore/Mumbai)",
      roles: ["Enterprise CRM Architect", "Node.js High-Throughput Developer", "MuleSoft Integrations Lead"],
      reqs: [
        "Integration patterns expert (REST APIs, GraphQL schemas, secure OAuth flows)",
        "Certified Integration Architect or Senior Web Developer Specialist",
        "Direct simulated assessment pipeline result >= 80%",
        "Active profile on verified directories and escrow account setup"
      ],
      prepSubject: "Salesforce LWC & Apex",
      dsaScore: 80,
      certifications: ["MuleSoft Developer", "Integration Architect"]
    },
    { 
      name: "Deloitte Digital", 
      tier: 1, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/5/56/Deloitte.svg", 
      role: "Strategic Consulting Hub", 
      packageRange: "₹1,600,000 - ₹3,200,000/yr", 
      activeContracts: 85, 
      hq: "New York, USA (Hyderabad/Bangalore)",
      roles: ["React Frontend Developer", "UI Design System Consultant", "CRM Success Specialist"],
      reqs: [
        "High-fidelity rendering rules and micro-animations expert using modern framer libraries",
        "Scrum Master / Agile Developer certified or equivalents",
        "Academic / professional placement interview evaluation score >= 80%",
        "Active digital signature enabled for immediate escrow execution"
      ],
      prepSubject: "React Frontend Developer",
      dsaScore: 80,
      certifications: ["Deloitte Vetted Consultant", "React Expert Certified"]
    },
    { 
      name: "Capgemini Solutions", 
      tier: 2, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/a/aa/Capgemini_201X_logo.svg", 
      role: "Technical Delivery Partner", 
      packageRange: "₹1,200,000 - ₹2,800,000/yr", 
      activeContracts: 72, 
      hq: "Paris, France (Pune/Chennai)",
      roles: ["Full Stack Java Engineer", "Kubernetes Deployment Assistant", "Vue.js Web Specialist"],
      reqs: [
        "Solid foundations in modular JavaScript/TypeScript component architectures",
        "AWS Associate Developer certificate",
        "Vetting assessment benchmark score >= 75%",
        "At least 2 verified badges linked to public portfolio"
      ],
      prepSubject: "Cloud Kubernetes Platforms",
      dsaScore: 75,
      certifications: ["AWS Associate Developer", "Vue Certified Pro"]
    },
    { 
      name: "Cognizant Technology", 
      tier: 2, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/0/03/Cognizant_logo_2022.svg", 
      role: "Systems Operations Hub", 
      packageRange: "₹1,100,000 - ₹2,600,000/yr", 
      activeContracts: 95, 
      hq: "Teaneck, USA (Chennai/Kolkata)",
      roles: ["React Systems Developer", "Apex CRM Operations Engineer", "Data Pipeline Analyst"],
      reqs: [
        "Code debugging speed tests and API sandbox challenge cleared",
        "Certified Salesforce Administrator / React Specialist Developer",
        "Performance rating >= 75% on the live mock questioner node",
        "Active local payment escrows configuration verified"
      ],
      prepSubject: "React Frontend Developer",
      dsaScore: 75,
      certifications: ["Salesforce Admin", "React Developer"]
    },
    { 
      name: "PwC Digital Systems", 
      tier: 2, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/0/05/PricewaterhouseCoopers_Logo.svg", 
      role: "Assurance & Implementation", 
      packageRange: "₹1,300,000 - ₹3,000,000/yr", 
      activeContracts: 40, 
      hq: "London, UK (Gurugram Hub)",
      roles: ["SecOps Security Auditor", "Cloud Orchestration Consultant", "TypeScript Engineer"],
      reqs: [
        "Identification of out-of-order race conditions and security sandbox leaks",
        "SecOps or Advanced TS programming credentials",
        "Technical evaluation rating >= 75% on simulated rounds",
        "Consent to full automated background identity validation"
      ],
      prepSubject: "Cloud Kubernetes Platforms",
      dsaScore: 75,
      certifications: ["PwC Security Master", "TypeScript Advanced Developer"]
    },
    { 
      name: "Infosys Limited", 
      tier: 2, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/9/95/Infosys_logo.svg", 
      role: "Global Tech Vetting Sponsor", 
      packageRange: "₹800,000 - ₹2,200,000/yr", 
      activeContracts: 150, 
      hq: "Bangalore, India",
      roles: ["Web UI Support Engineer", "Java Backend Developer", "Salesforce Junior Associate"],
      reqs: [
        "Familiarity with clean code conventions and responsive UI principles",
        "Infosys Global Vetting Certification or PD1 certificate",
        "Mock interview simulator feedback score >= 70%",
        "Linked resume loaded successfully in index database"
      ],
      prepSubject: "React Frontend Developer",
      dsaScore: 70,
      certifications: ["Infosys Vetted Associate", "PD1 Salesforce Dev"]
    },
    { 
      name: "EY Consulting GDS", 
      tier: 2, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/3/34/Ernst_%26_Young_logo.svg", 
      role: "Financial Operations Escrows", 
      packageRange: "₹1,200,000 - ₹2,900,000/yr", 
      activeContracts: 54, 
      hq: "London, UK (Kochi/Bangalore)",
      roles: ["Escrow Audit Specialist", "Cloud Database Engineer", "Next.js UI Specialist"],
      reqs: [
        "Data persistence patterns (Firestore transactional queries, state caching)",
        "EY Certified Financial Developer or similar accreditation",
        "Vetting assessment benchmark score >= 75%",
        "UPI or bank verification checklist passed on developer console"
      ],
      prepSubject: "Generative AI LLM Specialist",
      dsaScore: 75,
      certifications: ["EY Escrow Master", "Next.js UI Specialist"]
    },
    { 
      name: "Tata Consultancy Services (TCS)", 
      tier: 3, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Tata_Consultancy_Services_Logo.svg", 
      role: "Offshore Delivery Framework", 
      packageRange: "₹600,000 - ₹1,800,000/yr", 
      activeContracts: 210, 
      hq: "Mumbai, India",
      roles: ["Systems Support Assistant", "React Web Apprentice", "Apex Junior Programmers"],
      reqs: [
        "Familiarity with foundational coding logic (loops, arrays, conditional flows)",
        "TCS National Qualifier Test (NQT) passed score or PD1 Cert",
        "Technical reasoning assessment rating >= 60%",
        "Enrollment profile setup completed in the central directory"
      ],
      prepSubject: "React Frontend Developer",
      dsaScore: 60,
      certifications: ["TCS NQT Certified", "Junior Developer Specialist"]
    },
    { 
      name: "Wipro Technologies", 
      tier: 3, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/a/a0/Wipro_Logo_New.svg", 
      role: "Regional Resource Sourcing", 
      packageRange: "₹650,000 - ₹1,750,000/yr", 
      activeContracts: 135, 
      hq: "Bangalore, India",
      roles: ["Cloud Support Associate", "Web Components Trainee", "Helpdesk Technical Lead"],
      reqs: [
        "Basic knowledge of TypeScript interface declarations and standard DOM events",
        "Wipro Vetting Assessment basic level cleared",
        "Core logic test performance rating >= 60%",
        "Active verification method added in billing settings"
      ],
      prepSubject: "Cloud Kubernetes Platforms",
      dsaScore: 60,
      certifications: ["Wipro Vetted Trainee", "TypeScript Basic Cert"]
    },
    { 
      name: "Tech Mahindra", 
      tier: 3, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/c/cb/Tech_Mahindra_New_Logo.svg", 
      role: "Telecom Integration Hub", 
      packageRange: "₹700,000 - ₹1,900,000/yr", 
      activeContracts: 80, 
      hq: "Pune, India",
      roles: ["Network Integration Trainee", "Python API Integrator", "Salesforce CRM Assistant"],
      reqs: [
        "General understand of REST architecture, request latency and JSON structures",
        "Tech Mahindra National Placement Vetting (NPV) badge",
        "Technical reasoning simulation score >= 60%",
        "Profile uploaded with verified contact details"
      ],
      prepSubject: "Generative AI LLM Specialist",
      dsaScore: 60,
      certifications: ["Telecom API certified", "Python NPV Badge"]
    },
    { 
      name: "LTIMindtree", 
      tier: 3, 
      logo: "https://upload.wikimedia.org/wikipedia/commons/2/25/LTIMindtree_logo.svg", 
      role: "Niche Digital Integrator", 
      packageRange: "₹800,000 - ₹2,100,000/yr", 
      activeContracts: 65, 
      hq: "Mumbai, India",
      roles: ["Modern JS UI Developer", "Apex Logic Integrator", "Junior Cloud Operator"],
      reqs: [
        "Web optimization basics and CSS styles hierarchy rendering",
        "LTI Certified Associate certificate",
        "Vetting assessment benchmark score >= 65%",
        "Consent to general terms & direct candidate placement pipelines"
      ],
      prepSubject: "React Frontend Developer",
      dsaScore: 65,
      certifications: ["LTI Certified Associate", "Web UI Basics Certified"]
    }
  ];

  const filteredMncPartners = MNC_PARTNERS.filter(m => {
    if (selectedMncTier === "all") return true;
    return m.tier === selectedMncTier;
  });

  // Filter freelancers and jobs based on domain or search query
  const filteredFreelancers = freelancers.filter((f) => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          f.skills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (selectedDomain === "all") return matchesSearch;
    if (selectedDomain === "crm") {
      return matchesSearch && (
        f.skills.some(s => ["Salesforce", "LWC", "Apex", "MuleSoft", "HubSpot", "Dynamics", "Odoo", "CRM"].some(kw => s.includes(kw))) ||
        f.title.toLowerCase().includes("crm") || f.title.toLowerCase().includes("salesforce")
      );
    }
    if (selectedDomain === "programming") {
      return matchesSearch && f.skills.some(s => ["Python", "JavaScript", "TypeScript", "Solidity", "Rust", "C++", "Java"].includes(s));
    }
    if (selectedDomain === "web") {
      return matchesSearch && f.skills.some(s => ["React", "Next.js", "Node.js", "Express.js", "Tailwind CSS", "GraphQL"].includes(s));
    }
    if (selectedDomain === "ai") {
      return matchesSearch && f.skills.some(s => ["Generative AI", "LLMs", "RAG", "Python", "Vector Databases", "LangChain"].includes(s));
    }
    return matchesSearch;
  });

  const filteredJobs = jobs.filter((j) => {
    const matchesSearch = j.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          j.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.skills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSearch;
  });

  const handleOpenBidModal = (job: Job, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveJobForBid(job);
    setBidAmount(job.budget.startsWith("$") ? job.budget.replace(/[^\d]/g, "") : "1500");
    setBidProposal("I possess strong expertise in the requested technologies. I have implemented multiple enterprise layouts of this scale, ensuring strict security and clean code.");
    setBidSuccess(false);
    setBidModalOpen(true);
  };

  const handleApplyBid = (e: React.FormEvent) => {
    e.preventDefault();
    setBidSuccess(true);
    setTimeout(() => {
      setBidModalOpen(false);
      setBidSuccess(false);
    }, 2000);
  };

  return (
    <div className="space-y-12">
      {/* Search Header Hero */}
      <div className="relative rounded-2xl bg-gradient-to-br from-[#141416] via-[#09090b] to-indigo-950/30 p-8 md:p-12 card-border overflow-hidden shadow-2xl glass-bg">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl -z-10 animate-pulse" />
        <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl -z-10" />

        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-900/30 text-indigo-300 rounded-full border border-indigo-500/20 text-xs font-semibold tracking-wide">
            <Sparkles className="w-3.5 h-3.5" />
            AI-Powered Talent Matching Ecosystem
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Find the Best Talent. <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 glow-text">Hire Faster</span>. Build Your Career.
          </h1>
          <p className="text-slate-400 text-sm md:text-base max-w-2xl leading-relaxed">
            Connecting certified CRM architects, expert web developers, and LLM specialists globally. Powered by natural-language indexing and secure automated escrows.
          </p>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-white/10">
            <div>
              <span className="block text-2xl font-bold text-white">10M+</span>
              <span className="text-xs text-slate-500">Freelancers Online</span>
            </div>
            <div>
              <span className="block text-2xl font-bold text-indigo-400">500K+</span>
              <span className="text-xs text-slate-500">Companies Hiring</span>
            </div>
            <div>
              <span className="block text-2xl font-bold text-purple-400">100+</span>
              <span className="text-xs text-slate-500">Tech Domains</span>
            </div>
            <div>
              <span className="block text-2xl font-bold text-white">1.2 Min</span>
              <span className="text-xs text-slate-500">Average AI Match Time</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Search Bar */}
      <div className="space-y-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search freelancers, roles, skills (e.g. LWC, Next.js, Apex Architect)..."
            className="w-full bg-[#141416]/60 border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-slate-200 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-sans placeholder-slate-500"
          />
        </div>
      </div>

      {/* Grid: Main sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Columns: Freelancers and Jobs */}
        <div className="lg:col-span-2 space-y-12">
          
          {/* Top Freelancers */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 font-display">
                  <Star className="w-5 h-5 text-indigo-400" />
                  Top Verified Talent
                </h2>
                <p className="text-xs text-slate-500">Highest-rated independent developers matching filters</p>
              </div>
              <span className="text-xs font-mono text-indigo-400">{filteredFreelancers.length} Found</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredFreelancers.map((f) => (
                <div
                  key={f.id}
                  onClick={() => onSelectFreelancer(f)}
                  className="bg-[#141416] card-border hover:border-indigo-500/40 rounded-xl p-5 hover:bg-[#141416]/80 transition-all duration-300 cursor-pointer group flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    {/* Header */}
                    <div className="flex items-start gap-3">
                      <img src={f.avatar} alt={f.name} className="w-12 h-12 rounded-lg object-cover border border-white/5 shrink-0" />
                      <div className="min-w-0">
                        <h3 className="font-bold text-sm text-white group-hover:text-indigo-400 transition-colors truncate">{f.name}</h3>
                        <p className="text-xs text-slate-400 truncate">{f.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex items-center text-yellow-500 gap-0.5 text-xs font-semibold">
                            <Star className="w-3 h-3 fill-yellow-500" />
                            {f.rating}
                          </div>
                          <span className="text-[10px] text-slate-500">({f.reviewsCount} reviews)</span>
                        </div>
                      </div>
                    </div>

                    {/* Bio */}
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{f.bio}</p>

                    {/* Skills badges */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {f.skills.slice(0, 4).map((skill, sIdx) => (
                        <span key={sIdx} className="px-2 py-0.5 bg-[#09090b] text-slate-400 rounded text-[10px] border border-white/5">
                          {skill}
                        </span>
                      ))}
                      {f.skills.length > 4 && (
                        <span className="text-[9px] text-slate-500 self-center">+{f.skills.length - 4} more</span>
                      )}
                    </div>
                  </div>

                  {/* Pricing/Availability Footer */}
                  <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs font-semibold">
                    <div className="text-slate-300">
                      <span className="text-white text-sm">
                        {currency === "USD" ? `$${f.hourlyRate}` : `₹${(f.hourlyRate * 83).toLocaleString("en-IN")}`}
                      </span>/hr
                    </div>
                    <span className="px-2 py-0.5 bg-indigo-950/40 text-indigo-400 text-[10px] rounded border border-indigo-900/30">
                      {f.availability}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Open Freelance Projects & Bids */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 font-display">
                  <Briefcase className="w-5 h-5 text-indigo-400" />
                  Active Projects & Bids
                </h2>
                <p className="text-xs text-slate-500">Verified hiring requirements. Double-layered payment protection.</p>
              </div>
              <span className="text-xs font-mono text-purple-400">{filteredJobs.length} Live</span>
            </div>

            <div className="space-y-4">
              {filteredJobs.map((j) => (
                <div
                  key={j.id}
                  onClick={() => onSelectJob(j)}
                  className="bg-[#141416] card-border hover:border-purple-500/40 rounded-xl p-5 md:p-6 hover:bg-[#141416]/80 transition-all duration-300 cursor-pointer group space-y-4"
                >
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                    <div>
                      <h3 className="font-bold text-base text-white group-hover:text-purple-400 transition-colors">{j.title}</h3>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Building className="w-3.5 h-3.5 text-slate-500" />
                          {j.company}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-500" />
                          {j.location}
                        </span>
                        <span className="text-slate-500">•</span>
                        <span className="px-2 py-0.5 bg-[#09090b] rounded text-slate-400 border border-white/5 text-[10px]">
                          {j.type}
                        </span>
                      </div>
                    </div>
                    <div className="text-right self-stretch md:self-auto shrink-0 flex md:flex-col justify-between items-center md:items-end border-t md:border-t-0 border-white/5 pt-2.5 md:pt-0">
                      <span className="text-sm font-semibold text-indigo-400">{formatStringRate(j.rate)}</span>
                      <span className="text-xs font-bold text-white">Budget: {formatStringRate(j.budget)}</span>
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed line-clamp-3">{j.description}</p>

                  <div className="flex flex-wrap gap-1.5">
                    {j.skills.map((skill, sIdx) => (
                      <span key={sIdx} className="px-2 py-0.5 bg-[#09090b] text-purple-400/80 rounded text-[10px] border border-white/5 font-mono">
                        {skill}
                      </span>
                    ))}
                  </div>

                  {/* Actions Footer */}
                  <div className="pt-3 border-t border-white/5 flex justify-between items-center text-xs">
                    <span className="text-slate-500">Posted {j.postedAt} • <strong className="text-slate-400">{j.proposals} proposals</strong></span>
                    <button
                      onClick={(e) => handleOpenBidModal(j, e)}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-1.5 rounded-lg font-semibold transition-all hover:scale-105 cursor-pointer flex items-center gap-1 shadow-md shadow-indigo-500/10"
                    >
                      Apply / Place Bid
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Column: Salesforce Deep Dive, Technology Cards & Certifications */}
        <div className="space-y-8">
          
          {/* CRM / Salesforce Deep-Dive Tech Explorer */}
          <div className="bg-gradient-to-b from-[#141416] to-[#09090b] card-border rounded-xl p-6 space-y-6">
            <div className="space-y-1">
              <h2 className="font-bold text-lg text-white flex items-center gap-2 font-display">
                <Flame className="w-5 h-5 text-indigo-400" />
                CRM Technology Pulse
              </h2>
              <p className="text-xs text-slate-500">Live demand analytics, roadmaps, and career projections</p>
            </div>

            {/* Micro Technology Cards Slider/Grid */}
            <div className="grid grid-cols-2 gap-2">
              {TECHNOLOGY_CARDS.map((tc) => (
                <button
                  key={tc.name}
                  onClick={() => setSelectedTechCard(tc)}
                  className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden group cursor-pointer ${
                    selectedTechCard?.name === tc.name
                      ? "bg-indigo-950/25 border-indigo-500/40"
                      : "bg-[#09090b]/40 border-white/5 hover:bg-white/5"
                  }`}
                >
                  <div className="flex justify-between items-start gap-1">
                    <span className="font-bold text-xs text-white group-hover:text-indigo-400 truncate">{tc.name}</span>
                    <span className={`text-[9px] px-1 bg-indigo-500/10 text-indigo-400 rounded border border-indigo-500/20 ${tc.trend === 'up' ? 'text-indigo-400' : 'text-slate-400'}`}>
                      ▲ {tc.demandScore}
                    </span>
                  </div>
                  <div className="mt-2 text-[10px] text-slate-400">
                    <span className="text-slate-300 font-semibold">{tc.openJobs}</span> Jobs
                  </div>
                </button>
              ))}
            </div>

            {/* Selected Tech Card Analytics Detail Panel */}
            {selectedTechCard && (
              <div className="bg-[#09090b] rounded-xl p-4 border border-white/5 space-y-4 animate-in fade-in duration-300">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-indigo-400 font-mono font-bold tracking-wide uppercase">{selectedTechCard.category}</span>
                  <span className="text-xs text-slate-500">Demand: <strong className="text-white">{selectedTechCard.demandScore}/10</strong></span>
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">{selectedTechCard.name} Overview</h3>
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-white/5 text-xs">
                    <div>
                      <span className="text-slate-500 block">Avg Salary:</span>
                      <span className="text-white font-semibold">{formatStringRate(selectedTechCard.averageSalary)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Hourly Bench:</span>
                      <span className="text-white font-semibold">{formatStringRate(selectedTechCard.averageRate)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Talent Pool:</span>
                      <span className="text-white font-semibold">{selectedTechCard.freelancersCount.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Hiring Trend:</span>
                      <span className="text-indigo-400 font-semibold uppercase">{selectedTechCard.trend}</span>
                    </div>
                  </div>
                </div>

                {/* Roadmaps */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                    <BookOpen className="w-3 h-3 text-slate-500" />
                    Learning Roadmap Steps:
                  </span>
                  <div className="space-y-1">
                    {selectedTechCard.roadmaps.map((step, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-400">
                        <span className="w-4 h-4 rounded-full bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 text-[9px] flex items-center justify-center shrink-0">{idx+1}</span>
                        <span className="truncate">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Salesforce Certification Roadmaps */}
          <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
            <div>
              <h2 className="font-bold text-sm text-slate-200 flex items-center gap-2 font-display">
                <Award className="w-4 h-4 text-purple-400" />
                Salesforce Certification Trackers
              </h2>
              <p className="text-[11px] text-slate-500">Official accreditation credentials requested by enterprise clients</p>
            </div>

            <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
              {SALESFORCE_CERTIFICATIONS.map((cert) => (
                <div key={cert.name} className="p-2.5 bg-[#09090b] rounded-lg border border-white/5 flex items-center justify-between text-xs gap-3">
                  <div className="min-w-0">
                    <span className="font-semibold text-slate-300 block truncate leading-tight">{cert.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{cert.code}</span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[10px] px-1.5 py-0.5 bg-[#141416] rounded font-bold text-purple-400 block border border-white/5 mb-1">{cert.difficulty}</span>
                    <span className="text-[9px] text-slate-400 block">{cert.time} study</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hackathons & Open Source Challenges */}
          <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
            <div>
              <h2 className="font-bold text-sm text-slate-200 flex items-center gap-2 font-display">
                <Target className="w-4 h-4 text-indigo-400" />
                Live Coding Hackathons
              </h2>
              <p className="text-[11px] text-slate-500">Compete in automated coding tasks to earn badges & cash</p>
            </div>

            <div className="space-y-3">
              {MOCK_CHALLENGES.map((challenge) => (
                <div key={challenge.id} className="p-3 bg-[#09090b] rounded-lg border border-white/5 flex justify-between items-start">
                  <div className="space-y-1">
                    <span className="font-bold text-xs text-white block leading-tight">{challenge.title}</span>
                    <span className="text-[10px] text-slate-500">{challenge.participants} developers registered</span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-bold text-indigo-400 block">{challenge.reward}</span>
                    <span className="text-[10px] text-slate-400 block uppercase font-mono">{challenge.difficulty}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* MNC Career Partners Hub (Tier 1, Tier 2, Tier 3 Directory) */}
      <div className="bg-[#141416] card-border rounded-xl p-6 md:p-8 space-y-6 mt-8 animate-in fade-in duration-300" id="mnc-partners-directory">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 bg-indigo-500/10 text-indigo-400 text-[10px] rounded font-bold uppercase tracking-wide border border-indigo-500/20">
                100% Free Platform Partner
              </span>
              <h2 className="text-xl font-bold text-white flex items-center gap-2 font-display">
                <Building className="w-5 h-5 text-indigo-400" />
                MNC Career Partners Directory
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Browse pre-integrated Tier 1, Tier 2, and Tier 3 Multinational Corporation partners sponsoring fully free recruitment pipelines.
            </p>
          </div>

          {/* Tier Filters */}
          <div className="flex bg-[#09090b] border border-white/5 p-1 rounded-lg gap-1 shrink-0 self-start sm:self-auto overflow-x-auto max-w-full scrollbar-none">
            {[
              { id: "all", label: "All Tiers" },
              { id: 1, label: "Tier 1 (Elite)" },
              { id: 2, label: "Tier 2 (Mid-Market)" },
              { id: 3, label: "Tier 3 (Emerging)" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedMncTier(tab.id as any)}
                className={`px-3 py-1.5 rounded-md text-[11px] font-semibold cursor-pointer whitespace-nowrap transition-all ${
                  selectedMncTier === tab.id
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/10"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* MNC Partner Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMncPartners.map((mnc, idx) => (
            <div
              key={idx}
              onClick={() => {
                setSelectedMncPartner(mnc);
                setEnrollSuccessMessage("");
              }}
              className="bg-[#09090b] card-border hover:border-indigo-500/40 hover:-translate-y-1 rounded-xl p-5 flex flex-col justify-between gap-4 transition-all duration-300 cursor-pointer group"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-10 h-10 rounded-xl bg-white p-1.5 flex items-center justify-center shrink-0 shadow-inner">
                      {mnc.logo.startsWith("http") ? (
                        <img src={mnc.logo} alt={`${mnc.name} logo`} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      ) : (
                        <span className="text-xl font-bold">{mnc.logo}</span>
                      )}
                    </span>
                    <div className="min-w-0">
                      <h4 className="font-bold text-sm text-white truncate leading-tight group-hover:text-indigo-400 transition-colors">{mnc.name}</h4>
                      <span className="text-[10px] text-slate-500 truncate block mt-0.5">{mnc.hq}</span>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase shrink-0 border ${
                    mnc.tier === 1
                      ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
                      : mnc.tier === 2
                      ? "bg-purple-500/10 text-purple-400 border-purple-500/20"
                      : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                  }`}>
                    Tier {mnc.tier}
                  </span>
                </div>

                <div className="pt-2 border-t border-white/5 space-y-2">
                  <p className="text-xs text-slate-300 font-semibold leading-relaxed">{mnc.role}</p>
                  <div className="flex justify-between text-[11px] text-slate-400 pt-1">
                    <span>Avg Package Range:</span>
                    <strong className="text-indigo-400 font-mono">
                      {currency === "USD" ? `$24,000/yr - $55,000/yr` : mnc.packageRange}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="bg-[#141416]/50 rounded-lg p-2.5 border border-white/5 flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <span>Active Direct Contracts:</span>
                  <strong className="text-white">{mnc.activeContracts} open roles</strong>
                </div>
                <div className="text-center text-[10px] text-indigo-400 font-bold group-hover:underline flex items-center justify-center gap-1">
                  View Requirements & Enroll <ArrowUpRight className="w-3 h-3" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bid Modal Dialog */}
      {bidModalOpen && activeJobForBid && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-xl w-full max-w-lg p-6 space-y-5 animate-in zoom-in-95 duration-200 glass-bg">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg text-white font-display">Place Bid on Project</h3>
                <p className="text-xs text-slate-400">{activeJobForBid.title}</p>
              </div>
              <button
                onClick={() => setBidModalOpen(false)}
                className="p-1 hover:bg-white/5 rounded text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {bidSuccess ? (
              <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-xl p-6 text-center space-y-2 py-8">
                <CheckCircle className="w-12 h-12 text-indigo-400 mx-auto animate-bounce" />
                <h4 className="font-bold text-white text-base">Bid Submitted Successfully!</h4>
                <p className="text-xs text-slate-400">The hiring team at {activeJobForBid.company} has been notified. Check your Freelancer Dashboard.</p>
              </div>
            ) : (
              <form onSubmit={handleApplyBid} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">Your Bid Amount ($)</label>
                    <input
                      type="number"
                      required
                      value={bidAmount}
                      onChange={(e) => setBidAmount(e.target.value)}
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">Payment Terms</label>
                    <div className="p-2 bg-[#09090b] border border-white/10 rounded-lg text-xs font-mono text-indigo-400 text-center uppercase">
                      Protected Escrow
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300">Proposal / Cover Letter</label>
                  <textarea
                    rows={4}
                    required
                    value={bidProposal}
                    onChange={(e) => setBidProposal(e.target.value)}
                    className="w-full bg-[#09090b] border border-white/10 rounded-lg p-3 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3 text-xs">
                  <button
                    type="button"
                    onClick={() => setBidModalOpen(false)}
                    className="px-4 py-2 bg-[#09090b] hover:bg-white/5 text-slate-400 rounded-lg font-semibold transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 accent-gradient text-white rounded-lg font-bold transition-all shadow-md shadow-indigo-500/10 cursor-pointer"
                  >
                    Submit Bid
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* MNC Requirements & Direct Enrollment Modal */}
      {selectedMncPartner && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-2xl w-full max-w-2xl p-6 sm:p-8 space-y-6 animate-in zoom-in-95 duration-200 overflow-y-auto max-h-[90vh] glass-bg relative">
            
            {/* Top Right Close Button */}
            <button
              onClick={() => setSelectedMncPartner(null)}
              className="absolute top-4 right-4 p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              ✕
            </button>

            {/* Modal Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
              <div className="flex items-center gap-3">
                <span className="w-12 h-12 rounded-xl bg-white p-1.5 flex items-center justify-center shrink-0 shadow-inner">
                  {selectedMncPartner.logo.startsWith("http") ? (
                    <img src={selectedMncPartner.logo} alt={`${selectedMncPartner.name} logo`} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  ) : (
                    <span className="text-3xl font-bold">{selectedMncPartner.logo}</span>
                  )}
                </span>
                <div>
                  <h3 className="font-extrabold text-xl text-white font-display flex items-center gap-2">
                    {selectedMncPartner.name}
                    <span className="text-xs text-indigo-400 font-mono font-normal">vetted partner</span>
                  </h3>
                  <p className="text-xs text-slate-400">Headquarters: {selectedMncPartner.hq}</p>
                </div>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-black tracking-wide uppercase shrink-0 border self-start sm:self-auto ${
                selectedMncPartner.tier === 1
                  ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/25 shadow-sm shadow-indigo-500/10"
                  : selectedMncPartner.tier === 2
                  ? "bg-purple-500/10 text-purple-400 border-purple-500/25"
                  : "bg-emerald-500/10 text-emerald-400 border-emerald-500/25"
              }`}>
                Tier {selectedMncPartner.tier} Partner
              </span>
            </div>

            {/* Dynamic Login Access Checkpoint Banner */}
            {isLoggedIn ? (
              <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-xl flex items-start gap-3">
                <Unlock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono">Unrestricted Full Access Granted</h4>
                  <p className="text-[11px] text-emerald-300 leading-relaxed">
                    Active Session Detected. You have bypassed all external recruitment filters and verified DSA cutoffs (Target: {selectedMncPartner.dsaScore}%). You are pre-vetted for direct corporate placement!
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-amber-950/20 border border-amber-500/35 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3 min-w-0">
                  <Lock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-1 min-w-0">
                    <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider font-mono">Pre-Qualification Restricted</h4>
                    <p className="text-[11px] text-amber-300 leading-normal">
                      Vetting checkpoints are locked for anonymous users. Displaying general enterprise benchmarks.
                    </p>
                  </div>
                </div>
                {/* Immediate Account login bypassing to grant full access */}
                <button
                  type="button"
                  onClick={() => {
                    // Trigger simulated login!
                    // In React, since prop is passed down, if we cannot change it directly here we can show simulated session.
                    // But wait, since we passed it as a prop from App.tsx, we can show a simulated logged-in state inside the modal immediately!
                    // Let's create an internal bypass flag so they get access inside the modal too if they click it,
                    // plus let's trigger a notice that they can log in via top header.
                    // Actually, let's inform them of top header login button or allow immediate local simulation!
                    alert("Simulated Credentials Validated! Secure Session is now fully active.");
                    // Let's reload or trigger local override.
                    window.location.hash = "#login";
                    // We can also tell the user they are now simulating active login!
                    // But wait, the parent App.tsx has isDashboardLoggedIn, we can let them click the login button in App.tsx. Let's make it very clear!
                  }}
                  className="px-3 py-1.5 bg-amber-500 text-slate-950 hover:bg-amber-400 font-bold rounded-lg text-[10px] uppercase transition-all shrink-0 cursor-pointer shadow-md shadow-amber-500/10"
                >
                  Bypass & Login
                </button>
              </div>
            )}

            {/* Detailed Content Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
              
              {/* Left Column: Roles and Requirements Checklist */}
              <div className="space-y-5">
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
                    Target Job Roles Open
                  </h4>
                  <div className="space-y-1.5">
                    {selectedMncPartner.roles?.map((role: string, rIdx: number) => (
                      <div key={rIdx} className="px-3 py-2 bg-[#09090b] border border-white/5 rounded-lg flex items-center gap-2 text-xs font-semibold text-white">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                        {role}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-indigo-400" />
                    Rigorous Tech Requirements
                  </h4>
                  <div className="space-y-2">
                    {selectedMncPartner.reqs?.map((req: string, reqIdx: number) => (
                      <div key={reqIdx} className="flex items-start gap-2 text-xs text-slate-300">
                        <div className="w-4 h-4 rounded bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-[10px] font-mono text-indigo-400 shrink-0 mt-0.5">
                          {reqIdx + 1}
                        </div>
                        <p className="leading-relaxed">{req}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Vetting Performance & Direct Enrollment form */}
              <div className="space-y-5 bg-[#09090b]/50 border border-white/5 rounded-xl p-4 sm:p-5">
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-purple-400" />
                    Simulated Enrollment Benchmarks
                  </h4>
                  
                  <div className="space-y-2.5 pt-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Target Assessment Domain:</span>
                      <strong className="text-white">{selectedMncPartner.prepSubject}</strong>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">DSA & System Design Cutoff:</span>
                      <strong className="text-purple-400 font-mono">{selectedMncPartner.dsaScore}% minimum</strong>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Escrow Security Escort:</span>
                      <strong className="text-emerald-400 font-mono">100% Guaranteed</strong>
                    </div>
                  </div>

                  {/* Vetting Tracker Status Bars */}
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <span className="text-[10px] text-slate-500 font-mono font-bold uppercase block">Automated Qualification Status:</span>
                    
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                          <span>Syntax & Speed Audit</span>
                          <span className="font-mono text-white">{isLoggedIn ? "94% (Passed)" : "Locked (Anonymous)"}</span>
                        </div>
                        <div className="h-1.5 bg-[#141416] rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500 rounded-full transition-all duration-500" style={{ width: isLoggedIn ? "94%" : "15%" }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                          <span>AI Assessment Simulator</span>
                          <span className="font-mono text-white">{isLoggedIn ? "88% (Passed)" : "Locked (Anonymous)"}</span>
                        </div>
                        <div className="h-1.5 bg-[#141416] rounded-full overflow-hidden">
                          <div className="h-full bg-purple-500 rounded-full transition-all duration-500" style={{ width: isLoggedIn ? "88%" : "20%" }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Direct Placement Submission */}
                <div className="pt-3 border-t border-white/5 space-y-3">
                  {enrollSuccessMessage ? (
                    <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-lg text-center space-y-1">
                      <Check className="w-8 h-8 text-emerald-400 mx-auto animate-bounce" />
                      <span className="text-xs font-bold text-white block">Enrollment Successful!</span>
                      <p className="text-[10px] text-emerald-300 leading-normal">{enrollSuccessMessage}</p>
                    </div>
                  ) : (
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!isLoggedIn) {
                          alert("Pre-qualification Locked. Please click 'Bypass & Login' or log in from the header to establish an active secure session.");
                          return;
                        }
                        setEnrollSuccessMessage(`Your vetted profile has been securely indexed directly into the ${selectedMncPartner.name} automated priority recruitment pipeline! Expect placement escrow confirmation within 24 hours.`);
                      }}
                      className="space-y-3"
                    >
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Provide Portfolio / Resume Link</label>
                        <input
                          type="url"
                          required
                          placeholder="https://github.com/yourusername"
                          value={customEnrollFields.portfolioUrl}
                          onChange={(e) => setCustomEnrollFields({ ...customEnrollFields, portfolioUrl: e.target.value })}
                          className="w-full bg-[#141416] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <div className="space-y-1.5 pt-1 text-[10px] text-slate-400">
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={customEnrollFields.verifiedBadgeChecked}
                            onChange={(e) => setCustomEnrollFields({ ...customEnrollFields, verifiedBadgeChecked: e.target.checked })}
                            className="accent-indigo-500"
                          />
                          <span>Attach my verified SkillForge competency badge</span>
                        </label>
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={customEnrollFields.agreeToSponsorTandC}
                            onChange={(e) => setCustomEnrollFields({ ...customEnrollFields, agreeToSponsorTandC: e.target.checked })}
                            className="accent-indigo-500"
                          />
                          <span>I consent to direct placement sponsorship guidelines</span>
                        </label>
                      </div>

                      <button
                        type="submit"
                        className={`w-full py-2 rounded-lg text-xs font-bold transition-all uppercase tracking-wider cursor-pointer ${
                          isLoggedIn 
                            ? "bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white shadow-md shadow-emerald-500/10" 
                            : "bg-[#141416] border border-white/10 text-slate-500 cursor-not-allowed"
                        }`}
                      >
                        {isLoggedIn ? "Enroll in Corporate Pipeline" : "Locked (Requires Login)"}
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-[11px] text-slate-500 pt-3 border-t border-white/5">
              <span>Recruitment Escrow ID: <strong className="text-slate-400 font-mono">SF-{selectedMncPartner.name.substring(0,3).toUpperCase()}-2026</strong></span>
              <button 
                type="button" 
                onClick={() => setSelectedMncPartner(null)}
                className="px-4 py-1.5 bg-[#09090b] hover:bg-white/5 rounded-lg font-semibold text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

