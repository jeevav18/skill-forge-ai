import React, { useState, useEffect } from "react";
import { 
  Compass, Sparkles, LayoutDashboard, Info, DollarSign, Bell, Star, MapPin, 
  Mail, MessageSquare, ShieldCheck, Award, Github, Linkedin, ExternalLink, 
  Menu, X, Laptop, Bot, Shield, Loader2, Sparkle, Globe, Calendar, ArrowUpRight,
  KeyRound
} from "lucide-react";
import { Freelancer, Job, Company, ViewMode } from "./types";
import ExploreTab from "./components/ExploreTab";
import AIWorkspaceTab from "./components/AIWorkspaceTab";
import DashboardsTab from "./components/DashboardsTab";
import AIChatDrawer from "./components/AIChatDrawer";

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>("explore");
  const [activeWorkspaceTool, setActiveWorkspaceTool] = useState<any>("search");
  const [activeDashboardTab, setActiveDashboardTab] = useState<any>("freelancer");
  const [activeAcademyDomain, setActiveAcademyDomain] = useState<"ai" | "webdev" | "crm" | "emerging">("ai");
  const [selectedDomain, setSelectedDomain] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isDashboardLoggedIn, setIsDashboardLoggedIn] = useState(true);

  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Custom Indian Currency and Support States
  const [currency, setCurrency] = useState<"USD" | "INR">("INR");
  const [supportOpen, setSupportOpen] = useState(false);

  // Selected details modal state
  const [selectedFreelancer, setSelectedFreelancer] = useState<Freelancer | null>(null);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [contactSuccess, setContactSuccess] = useState(false);
  const [contactMessage, setContactMessage] = useState("");

  // Navigation menu toggle for mobile
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Load platform data from server
  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch("/api/platform-data");
        if (response.ok) {
          const data = await response.json();
          setFreelancers(data.freelancers || []);
          setJobs(data.jobs || []);
          setCompanies(data.companies || []);
        } else {
          throw new Error("Local fallback triggered");
        }
      } catch (err) {
        console.warn("Backend loading failed, executing local offline mockup data:", err);
        // Clean local fallbacks if server route failed
        setFreelancers([
          {
            id: "f-1",
            name: "Aravind Nair",
            title: "Lead Salesforce Technical Architect",
            avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
            location: "Bangalore, India",
            experience: "12 Years",
            hourlyRate: 85,
            expectedSalary: "₹3,500,000/yr",
            rating: 4.9,
            reviewsCount: 42,
            availability: "Available (30 hrs/wk)",
            skills: ["Salesforce Architect", "Apex Programming", "LWC", "Aura Components", "MuleSoft", "Agentforce"],
            certifications: ["Salesforce Certified Technical Architect (CTA)", "Platform Developer II"],
            bio: "Ex-Salesforce CTA. Specializes in multi-cloud architecture, complex MuleSoft integrations, and implementing Agentforce AI agents for enterprise Service Clouds.",
            socials: { github: "github.com/aravind-sf", linkedin: "linkedin.com/in/aravindsf" }
          },
          {
            id: "f-2",
            name: "Priya Sharma",
            title: "Senior Full-Stack React & Node.js Developer",
            avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
            location: "Mumbai, India",
            experience: "6 Years",
            hourlyRate: 50,
            expectedSalary: "₹1,800,000/yr",
            rating: 4.8,
            reviewsCount: 29,
            availability: "Available Immediately",
            skills: ["React", "Next.js", "TypeScript", "Node.js", "Express.js", "Tailwind CSS", "GraphQL"],
            certifications: ["AWS Certified Developer"],
            bio: "Passionate about building fast, highly responsive React/Next.js applications with gorgeous Tailwind interfaces. Skilled in real-time WebSockets and secure API design.",
            socials: { github: "github.com/priyadev", linkedin: "linkedin.com/in/priya-sharma" }
          },
          {
            id: "f-3",
            name: "Marcus Vance",
            title: "AI Engineering & LLM Specialist",
            avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
            location: "San Francisco, USA",
            experience: "5 Years",
            hourlyRate: 110,
            expectedSalary: "$165,000/yr",
            rating: 5.0,
            reviewsCount: 18,
            availability: "Part-time (20 hrs/wk)",
            skills: ["Python", "Generative AI", "LLMs", "RAG", "LangChain", "FastAPI"],
            certifications: ["Google Cloud Professional Machine Learning Engineer"],
            bio: "Specialist in building semantic search, RAG pipelines, and conversational AI agents. Expert in fine-tuning models and building production-ready GenAI backends.",
            socials: { github: "github.com/marcus-ai", linkedin: "linkedin.com/in/marcusvance" }
          }
        ]);
        setJobs([
          {
            id: "j-1",
            title: "Enterprise Salesforce Revenue Cloud (CPQ) Consultant",
            company: "CloudScale Solutions",
            location: "Remote (Worldwide)",
            type: "Contract (6 Months)",
            rate: "$75 - $90 / hr",
            budget: "$25,000+",
            skills: ["Salesforce Architect", "Revenue Cloud", "CPQ", "Flow Builder"],
            description: "Looking for an expert consultant to overhaul our current pricing logic and implement Salesforce CPQ/Revenue Cloud.",
            proposals: 14,
            postedAt: "2 days ago"
          },
          {
            id: "j-2",
            title: "Next.js 15 & Tailwind Frontend Developer for AI Platform",
            company: "BioGen AI Corp",
            location: "Remote",
            type: "Freelance",
            rate: "Fixed Price",
            budget: "$8,500",
            skills: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
            description: "We are building an intuitive portal for genomic sequence visualization. Need a designer-developer hybrid who can build exceptionally clean, interactive layouts.",
            proposals: 32,
            postedAt: "1 day ago"
          }
        ]);
        setCompanies([
          { name: "CloudScale Solutions", logo: "⚡", domain: "CRM Consulting", size: "150-500 employees", rating: 4.8 },
          { name: "BioGen AI Corp", logo: "🧬", domain: "Health Tech & AI", size: "50-100 employees", rating: 4.9 }
        ]);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess(true);
    setTimeout(() => {
      setSelectedFreelancer(null);
      setContactSuccess(false);
      setContactMessage("");
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-[#070709] tech-grid-pattern text-slate-200 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Top Banner Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#09090b]/80 backdrop-blur-md border-b border-white/10 px-4 sm:px-6 py-3.5 flex items-center justify-between glass-bg">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer md:hidden"
            id="btn-mobile-menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2" id="logo-branding">
            <div className="w-9 h-9 rounded-xl accent-gradient flex items-center justify-center font-black text-white text-lg tracking-wider shadow-lg shadow-indigo-500/20">
              FX
            </div>
            <div>
              <div className="font-extrabold text-base tracking-tight text-white flex items-center gap-1.5 font-display">
                FreelanceX<span className="text-indigo-400 font-normal">.ai</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono tracking-widest block leading-tight">SKILLFORGE PORTAL</span>
            </div>
          </div>
        </div>

        {/* Creator & Contact Credit on the Top Side */}
        <div className="hidden lg:flex flex-col items-center text-center space-y-0.5 bg-indigo-950/20 px-4 py-1.5 rounded-lg border border-indigo-500/10 max-w-sm">
          <span className="text-[10px] text-indigo-300 font-bold tracking-wider font-mono">
            CREATED BY JEEVA V • 100% FREE PLATFORM
          </span>
          <span className="text-[10px] text-slate-400">
            Direct Support: <a href="mailto:gopiiniyavan@gmail.com" className="text-indigo-400 hover:underline">gopiiniyavan@gmail.com</a>
          </span>
        </div>

        {/* Top bar tools */}
        <div className="flex items-center gap-4">
          {/* Currency Toggle */}
          <div className="flex bg-[#141416] border border-white/10 p-0.5 rounded-lg gap-0.5" id="currency-switcher">
            <button
              onClick={() => setCurrency("USD")}
              title="Switch to US Dollar ($)"
              className={`px-2 py-1 rounded text-[9px] font-bold transition-all cursor-pointer ${
                currency === "USD"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/15"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              USD ($)
            </button>
            <button
              onClick={() => setCurrency("INR")}
              title="Switch to Indian Rupee (₹)"
              className={`px-2 py-1 rounded text-[9px] font-bold transition-all cursor-pointer ${
                currency === "INR"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/15"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              INR (₹)
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-slate-400 bg-white/[0.02] px-3 py-1.5 rounded-lg border border-white/5">
            <Bot className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            Gemini Engine: <span className="text-indigo-400 font-bold uppercase">Active</span>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Persistent Login Button */}
            <button
              onClick={() => setViewMode("dashboards")}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 border ${
                isDashboardLoggedIn
                  ? "bg-emerald-950/25 text-emerald-400 border-emerald-500/20"
                  : viewMode === "dashboards"
                    ? "bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-500/20"
                    : "bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 border-indigo-500/20 hover:border-indigo-500/35"
              }`}
              id="persistent-header-login-btn"
              title={isDashboardLoggedIn ? "Session Active - Unrestricted Full Access" : "Navigate to secure Simulated Portals"}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isDashboardLoggedIn ? "Session: Active (Full Access)" : "Login"}</span>
            </button>

            <button className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors relative cursor-pointer">
              <Bell className="w-4 h-5" />
              <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-indigo-400 rounded-full" />
            </button>
            <div 
              onClick={() => setViewMode("dashboards")}
              className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-xs text-indigo-400 font-mono shadow-inner cursor-pointer hover:border-indigo-500/50 transition-all" 
              title="Active Client Profile (Click to access Simulated Portals)"
            >
              GM
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 relative">
        
        {/* Navigation Sidebar Drawer */}
        <aside className={`
          fixed md:sticky top-[69px] bottom-0 left-0 z-30
          w-64 bg-[#09090b] border-r border-white/10 p-5
          flex flex-col justify-between shrink-0 transition-transform duration-300
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}>
          <div className="space-y-6">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block px-3">Navigation Map</span>
              <nav className="space-y-1">
                {[
                  { id: "explore", label: "Talent & Jobs", icon: Compass },
                  { id: "ai-workspace", label: "AI Workspaces", icon: Sparkles, badge: "Premium" },
                  { id: "dashboards", label: "Simulated Portals", icon: LayoutDashboard },
                  { id: "about", label: "Accreditation & Pricing", icon: Info }
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setViewMode(item.id as ViewMode);
                        setSidebarOpen(false);
                      }}
                      className={`
                        w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer
                        ${viewMode === item.id 
                          ? "bg-white/5 text-white border border-white/10" 
                          : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.02]"}
                      `}
                    >
                      <span className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${viewMode === item.id ? "text-indigo-400" : "text-slate-500"}`} />
                        {item.label}
                      </span>
                      {item.badge && (
                        <span className="text-[9px] px-1.5 py-0.2 bg-indigo-500/10 text-indigo-400 rounded-full border border-indigo-500/20 font-bold">{item.badge}</span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Salesforce Cloud Quick Links */}
            <div className="space-y-2 pt-4 border-t border-white/10">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block px-3">CRM Integration Vectors</span>
              <div className="space-y-1 pl-3 text-xs text-slate-400">
                <div className="flex items-center gap-2 py-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  <span>Salesforce Clouds</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                  <span>MuleSoft Integrations</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                  <span>Agentforce AI Copilot</span>
                </div>
              </div>

              </div>
          </div>

          {/* Secure Escrow Protection Badge */}
          <div className="p-3 bg-[#141416] card-border rounded-xl space-y-1.5 text-xs">
            <span className="font-bold text-slate-300 flex items-center gap-1.5 font-display">
              <ShieldCheck className="w-4 h-4 text-indigo-400" /> Secure Payments
            </span>
            <p className="text-[10px] text-slate-500 leading-normal">
              All freelance and contract payouts are held securely in escrow pending milestones release.
            </p>
          </div>
        </aside>

        {/* Content Wrapper */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {loading ? (
            <div className="h-[400px] flex flex-col items-center justify-center space-y-3">
              <Loader2 className="w-10 h-10 text-indigo-400 animate-spin" />
              <span className="text-xs text-slate-500 font-mono">Initializing SkillForge Core Data...</span>
            </div>
          ) : (
            <div className="max-w-6xl mx-auto space-y-12">
              {viewMode === "explore" && (
                <ExploreTab 
                  freelancers={freelancers} 
                  jobs={jobs} 
                  companies={companies}
                  onSelectFreelancer={(f) => setSelectedFreelancer(f)}
                  onSelectJob={(j) => setSelectedJob(j)}
                  currency={currency}
                  selectedDomain={selectedDomain}
                  setSelectedDomain={setSelectedDomain}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  isLoggedIn={isDashboardLoggedIn}
                />
              )}

              {viewMode === "ai-workspace" && (
                <AIWorkspaceTab 
                  onSelectFreelancer={(f) => setSelectedFreelancer(f)}
                  activeTool={activeWorkspaceTool}
                  setActiveTool={setActiveWorkspaceTool}
                  academyDomain={activeAcademyDomain}
                  setAcademyDomain={setActiveAcademyDomain}
                />
              )}

              {viewMode === "dashboards" && (
                <DashboardsTab 
                  freelancers={freelancers} 
                  jobs={jobs} 
                  currency={currency}
                  activeTab={activeDashboardTab}
                  setActiveTab={setActiveDashboardTab}
                  isLoggedIn={isDashboardLoggedIn}
                  setIsLoggedIn={setIsDashboardLoggedIn}
                />
              )}

              {viewMode === "about" && (
                <div className="space-y-12 animate-in fade-in duration-300">
                  {/* Pricing Cards */}
                  <div className="space-y-8" id="free-access-pricing-section">
                    <div className="text-center space-y-2">
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/20 font-mono uppercase tracking-wide animate-pulse">
                        ★ 100% Commission-Free Vetted Marketplace ★
                      </div>
                      <h2 className="text-3xl md:text-5xl font-black text-white font-display tracking-tight">Full Access — Free</h2>
                      <p className="text-slate-400 text-xs sm:text-sm max-w-xl mx-auto">All premium features included, absolutely no restrictions. Funded entirely by direct enterprise placement sponsorships.</p>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto pt-4 items-stretch">
                      
                      {/* Left & Mid columns: Massive "Full Access — Free" Centerpiece */}
                      <div className="lg:col-span-2 bg-[#141416] border-2 border-indigo-500/40 rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-2xl shadow-indigo-500/5">
                        <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
                        <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
                        
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-6">
                          <div className="space-y-1">
                            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-bold px-2 py-0.5 rounded border border-indigo-500/20 font-mono uppercase tracking-widest">
                              ZERO FEES GUARANTEE
                            </span>
                            <h3 className="text-2xl font-bold text-white font-display">All-Inclusive Professional Tier</h3>
                            <p className="text-xs text-slate-400">Everything you need to level up your technical career, completely unlocked.</p>
                          </div>
                          
                          <div className="text-left sm:text-right">
                            <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                              ₹0 <span className="text-lg font-normal text-slate-400">/ $0</span>
                            </div>
                            <span className="text-xs text-slate-500 font-semibold block uppercase font-mono mt-1">perpetually free</span>
                          </div>
                        </div>

                        {/* List of 14 features in a clean two-column grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                          {[
                            "Unlimited job applications",
                            "Search jobs & internships across Tier 1, 2 & 3 companies",
                            "AI-powered job matching",
                            "Public profile & portfolio builder",
                            "AI Resume Builder",
                            "AI Proposal Generator",
                            "AI Interview Coach",
                            "Skill Assessments & Certifications",
                            "Community forum & discussions",
                            "Messaging & collaboration tools",
                            "Analytics dashboard",
                            "Verified badge",
                            "Priority in search results",
                            "Video introduction"
                          ].map((feat, i) => (
                            <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300 group">
                              <div className="w-4.5 h-4.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 group-hover:scale-110 transition-transform">
                                <ShieldCheck className="w-3 h-3" />
                              </div>
                              <span className="leading-tight">{feat}</span>
                            </div>
                          ))}
                        </div>

                        <div className="pt-6 border-t border-white/5">
                          <button 
                            onClick={() => {
                              setViewMode("dashboards");
                              setActiveDashboardTab("student");
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className="w-full bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold py-3.5 rounded-xl text-sm transition-all cursor-pointer shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 group"
                            id="join-free-primary-btn"
                          >
                            <span>Join Free — Start Searching</span>
                            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                          </button>
                        </div>
                      </div>

                      {/* Right column: "Work & Get Paid" & Trust Escrow Hub */}
                      <div className="bg-[#141416]/90 border border-white/10 rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-xl">
                        <div className="space-y-4">
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/20 font-mono uppercase tracking-widest inline-block">
                            100% SECURE ESCROWS
                          </span>
                          
                          <div className="space-y-2">
                            <h3 className="text-xl font-bold text-white font-display">Work & Get Paid</h3>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              Work with confidence using escrow-protected payments. Sponsoring MNCs and employers pre-fund each milestone before you start coding, ensuring guaranteed payouts.
                            </p>
                          </div>

                          <div className="bg-[#09090b] border border-white/5 p-4 rounded-xl space-y-3.5">
                            <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider font-mono">SUPPORTED DISPATCH GATEWAYS</span>
                            
                            <div className="grid grid-cols-2 gap-2.5">
                              {[
                                { name: "Stripe", fee: "Instant Transfer", color: "text-indigo-400" },
                                { name: "PayPal", fee: "Global Payouts", color: "text-sky-400" },
                                { name: "Razorpay", fee: "Direct Bank", color: "text-indigo-500" },
                                { name: "UPI Auto", fee: "Real-time Payout", color: "text-emerald-400" }
                              ].map((gw, idx) => (
                                <div key={idx} className="p-2.5 bg-[#141416] border border-white/5 rounded-lg text-xs flex flex-col">
                                  <span className={`font-bold ${gw.color}`}>{gw.name}</span>
                                  <span className="text-[9px] text-slate-500 mt-0.5">{gw.fee}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3 pt-4 border-t border-white/5">
                          <div className="flex items-center gap-2.5 text-xs text-slate-400">
                            <div className="p-1.5 rounded-full bg-slate-800 text-slate-300 shrink-0">
                              <Shield className="w-3.5 h-3.5" />
                            </div>
                            <span>Dual-signature contracts prevent payment disputes.</span>
                          </div>
                          
                          <button 
                            onClick={() => {
                              setViewMode("ai-workspace");
                              setActiveWorkspaceTool("draft-generator");
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className="w-full bg-transparent hover:bg-white/5 border border-white/10 hover:border-white/15 text-slate-300 hover:text-white py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <span>Explore Contract Drafter</span>
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Core Platform Mission About Section */}
                  <div className="bg-white/[0.02] border border-white/5 rounded-xl p-6 sm:p-8 space-y-4 max-w-4xl mx-auto">
                    <h3 className="text-lg font-bold text-white font-display">About FreelanceX.ai</h3>
                    <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                      FreelanceX.ai is designed to solve the critical friction points of modern tech recruiting. Traditional freelance portals suffer from slow candidate vetting and high payment risks. By combining state-of-the-art Generative AI matching algorithms, automated resume parsing trackers, real-time mock technical interview pipelines, and robust dual-signature secure escrow protections, we provide a unified digital environment where certified CRM and frontend experts connect instantly with leading corporations.
                    </p>
                  </div>
                </div>
              )}

              {/* ENTERPRISE FOOTER */}
              <footer className="border-t border-white/5 bg-[#0b0b0d] mt-16 pt-12 pb-8 px-4 sm:px-6 rounded-xl space-y-10" id="platform-enterprise-footer">
                {/* Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-[#141416]/50 rounded-xl border border-white/5">
                  {[
                    { value: "10M+", label: "Active Freelancers", color: "text-indigo-400" },
                    { value: "500K+", label: "Companies Hiring", color: "text-purple-400" },
                    { value: "100+", label: "Tech Domains", color: "text-emerald-400" },
                    { value: "₹200Cr+", label: "Paid to Freelancers", color: "text-amber-400" }
                  ].map((stat, idx) => (
                    <div key={idx} className="text-center space-y-1">
                      <span className={`text-2xl sm:text-3xl font-extrabold block tracking-tight ${stat.color}`}>{stat.value}</span>
                      <span className="text-[10px] sm:text-xs text-slate-500 font-medium uppercase tracking-wider">{stat.label}</span>
                    </div>
                  ))}
                </div>

                {/* Links & Contact Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
                  {/* Col 1 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">For Freelancers</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Browse Jobs</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("freelancer"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Create Profile</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("resume-parser"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">AI Resume Builder</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("interview-coach"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Skill Assessments</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("draft-generator"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Portfolio Builder</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("student"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Certifications</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("ai-suite-directory"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Learning Paths</button></li>
                    </ul>
                  </div>

                  {/* Col 2 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">For Companies</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("company"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Post a Job</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Browse Talent</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery("Solutions"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Companies Directory</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("search"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">AI Candidate Ranking</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("company"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Hiring Dashboard</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("admin"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Background Verification</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("recruiter"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Recruiter Tools</button></li>
                    </ul>
                  </div>

                  {/* Col 3 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Technologies</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("ai"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">AI & Machine Learning</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("webdev"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Web Development</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("emerging"); setSearchQuery("Blockchain"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Blockchain & Web3</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("emerging"); setSearchQuery("Cloud"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Cloud Computing</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("crm"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Salesforce & CRM</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("emerging"); setSearchQuery("DevOps"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">DevOps</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer text-indigo-400 font-semibold">All 100+ Domains</button></li>
                    </ul>
                  </div>

                  {/* Col 4 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Platform</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => setViewMode("about")} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">About FreelanceX</button></li>
                      <li><button onClick={() => alert("Blog Hub: Currently displaying archived entries for Salesforce Agentforce release & Next.js 15 template styling.")} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Blog</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Companies</button></li>
                      <li><button onClick={() => alert("Welcome to the Community board! Start chatting with local tech specialists using our persistent AI Copilot on the bottom-right corner.")} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Community</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setTimeout(() => { const el = document.getElementById("mock-challenges-section"); if (el) el.scrollIntoView({ behavior: "smooth" }); }, 100); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Hackathons</button></li>
                      <li><button onClick={() => setSupportOpen(true)} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Help Center</button></li>
                      <li><button onClick={() => setSupportOpen(true)} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Contact Us</button></li>
                    </ul>
                  </div>

                  {/* Col 5: Support / Have any queries? */}
                  <div className="col-span-2 lg:col-span-1 space-y-4 bg-[#141416] p-4 rounded-xl border border-white/5">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 font-display">
                      <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                      Have any queries?
                    </h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Reach out directly — we're happy to help.
                    </p>
                    <div className="space-y-1">
                      <a href="mailto:gopiiniyavan@gmail.com" className="text-xs font-mono text-indigo-400 hover:underline font-semibold block break-all">
                        gopiiniyavan@gmail.com
                      </a>
                      <span className="text-[9px] text-slate-500 block">Sponsor: JEEVA V</span>
                    </div>
                  </div>
                </div>

                {/* Legal & Author Signature Footer */}
                <div className="pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] text-slate-500">
                  <div className="space-y-1 text-center md:text-left">
                    <span>© 2026 FreelanceX, Inc. All rights reserved.</span>
                    <span className="block text-slate-400 font-semibold">Created by JEEVA V</span>
                  </div>

                  <div className="flex flex-wrap justify-center gap-4 text-slate-400">
                    <button onClick={() => alert("Privacy Policy Details: Fully secure database transactions under Indian & Global IT security norms.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Privacy Policy</button>
                    <span>·</span>
                    <button onClick={() => alert("Terms of Service: Direct contracts are verified with secure multi-sig escrow systems.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Terms of Service</button>
                    <span>·</span>
                    <button onClick={() => alert("Cookie Policy: Essential local browser cache storage only.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Cookie Policy</button>
                    <span>·</span>
                    <button onClick={() => alert("Accessibility Policy: High-contrast palette designed for screen readers.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Accessibility</button>
                  </div>
                </div>
              </footer>
            </div>
          )}
        </main>
      </div>

      {/* PERSISTENT AI CHAT DRAWER */}
      <AIChatDrawer />

      {/* DETAIL MODAL: FREELANCER DETAIL */}
      {selectedFreelancer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-xl w-full max-w-2xl p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200 glass-bg">
            <div className="flex justify-between items-start">
              <div className="flex gap-4">
                <img src={selectedFreelancer.avatar} alt={selectedFreelancer.name} className="w-16 h-16 rounded-lg object-cover border border-white/10 shrink-0" />
                <div>
                  <h3 className="text-xl font-bold text-white">{selectedFreelancer.name}</h3>
                  <p className="text-xs text-indigo-400 font-mono mt-0.5">{selectedFreelancer.title}</p>
                  <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-400">
                    <MapPin className="w-3.5 h-3.5" />
                    {selectedFreelancer.location}
                    <span>•</span>
                    <strong className="text-slate-300">{selectedFreelancer.experience} Experience</strong>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedFreelancer(null)}
                className="p-1 hover:bg-white/5 rounded text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Left col */}
              <div className="md:col-span-2 space-y-5">
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-500 uppercase">Consultant Bio</span>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{selectedFreelancer.bio}</p>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-500 uppercase block">Specialist Skills Stack</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedFreelancer.skills.map((s, idx) => (
                      <span key={idx} className="px-2.5 py-0.5 bg-[#09090b] text-slate-400 border border-white/5 rounded text-xs font-mono">{s}</span>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-500 uppercase block">Accredited Certifications</span>
                  <div className="space-y-1.5">
                    {selectedFreelancer.certifications.map((c, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-400">
                        <Award className="w-3.5 h-3.5 text-yellow-500 shrink-0" />
                        <span>{c}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right col: Contact / Hire Card */}
              <div className="space-y-4">
                <div className="bg-[#09090b] p-4 rounded-xl border border-white/10 space-y-4">
                  <div className="space-y-1 text-center">
                    <span className="text-slate-400 text-xs block">Hourly rate</span>
                    <span className="text-2xl font-black text-white">${selectedFreelancer.hourlyRate}/hr</span>
                    <span className="text-[10px] px-2 py-0.5 bg-indigo-950 text-indigo-400 rounded-full border border-indigo-900 block mt-1">{selectedFreelancer.availability}</span>
                  </div>

                  {contactSuccess ? (
                    <div className="p-3 bg-indigo-950/40 text-indigo-400 rounded-lg border border-indigo-500/30 text-center text-xs space-y-1 py-4">
                      <ShieldCheck className="w-6 h-6 mx-auto animate-bounce" />
                      <strong className="block">Message Dispatched!</strong>
                      <span className="text-[10px] opacity-80">Check your Recruiter dashboard.</span>
                    </div>
                  ) : (
                    <form onSubmit={handleContactSubmit} className="space-y-2.5">
                      <label className="block text-[11px] font-semibold text-slate-400">Secure Direct Message</label>
                      <textarea
                        rows={3}
                        required
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        placeholder={`e.g. Hi ${selectedFreelancer.name.split(" ")[0]}, we have a Salesforce task starting next week...`}
                        className="w-full bg-[#141416] border border-white/10 rounded-lg p-2.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="submit"
                        className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 rounded-lg text-xs transition-all cursor-pointer shadow"
                      >
                        Send Secure Message
                      </button>
                    </form>
                  )}
                </div>

                <div className="flex gap-2 justify-center text-xs">
                  {selectedFreelancer.socials.github && (
                    <a href={`https://${selectedFreelancer.socials.github}`} target="_blank" rel="noreferrer" className="p-2 bg-[#09090b] border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors">
                      <Github className="w-4 h-4" />
                    </a>
                  )}
                  {selectedFreelancer.socials.linkedin && (
                    <a href={`https://${selectedFreelancer.socials.linkedin}`} target="_blank" rel="noreferrer" className="p-2 bg-[#09090b] border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors">
                      <Linkedin className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DETAIL MODAL: JOB DETAIL */}
      {selectedJob && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-xl w-full max-w-xl p-6 space-y-5 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200 glass-bg">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold text-white">{selectedJob.title}</h3>
                <span className="text-xs text-indigo-400 font-mono mt-0.5">{selectedJob.company} • {selectedJob.location}</span>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="p-1 hover:bg-white/5 rounded text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-[#09090b] rounded-lg border border-white/10 text-xs">
                <div>
                  <span className="text-slate-500 block">Rate / Pricing:</span>
                  <strong className="text-white text-sm">{selectedJob.rate}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Target Budget:</span>
                  <strong className="text-indigo-400 text-sm">{selectedJob.budget}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Contract Format:</span>
                  <span className="px-2 py-0.5 bg-[#141416] rounded font-semibold text-slate-400 border border-white/5 uppercase text-[10px] block mt-0.5">{selectedJob.type}</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-500 uppercase block">Project Specification</span>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{selectedJob.description}</p>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-500 uppercase block">Required Technical Accreditation</span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedJob.skills.map((s, idx) => (
                    <span key={idx} className="px-2.5 py-0.5 bg-[#09090b] text-indigo-400 border border-white/5 rounded text-xs font-mono">{s}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex justify-between items-center text-xs text-slate-500">
              <span>Posted {selectedJob.postedAt} • {selectedJob.proposals} proposals placed</span>
              <button
                onClick={() => {
                  alert("Simulated proposal submission registered in secure database. Check simulated freelancer bids page!");
                  setSelectedJob(null);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-lg font-bold transition-all shadow cursor-pointer"
              >
                Submit Proposal Template
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Help & Creator Support Widget */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 font-sans" id="creator-support-widget">
        {supportOpen && (
          <div className="w-80 bg-[#141416] card-border rounded-xl p-5 shadow-2xl animate-in slide-in-from-bottom-5 duration-200 space-y-4">
            {/* Header */}
            <div className="flex justify-between items-start">
              <div className="space-y-0.5">
                <h4 className="font-bold text-sm text-white">SkillForge Partner Support</h4>
                <span className="text-[10px] text-indigo-400 font-mono tracking-wider font-semibold block uppercase">Direct Inquiry Hub</span>
              </div>
              <button
                onClick={() => setSupportOpen(false)}
                className="p-1 text-slate-500 hover:text-slate-300 rounded hover:bg-white/5 cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <p className="text-xs text-slate-400 leading-relaxed">
              Need partner onboarding, sponsorship details, or have technical queries? Contact the verified creator directly through this email:
            </p>

            {/* Verified Email Card */}
            <div className="p-3 bg-[#09090b] rounded-lg border border-white/5 space-y-1.5">
              <span className="text-[9px] text-slate-500 font-bold block uppercase">Direct Email Contact</span>
              <a
                href="mailto:gopiiniyavan@gmail.com"
                className="text-xs font-mono text-indigo-400 hover:underline hover:text-indigo-300 block break-all font-semibold"
              >
                gopiiniyavan@gmail.com
              </a>
            </div>

            {/* Short Mock Inquiry Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                alert("Query successfully dispatched to Jeeva V! We will respond to gopiiniyavan@gmail.com.");
                setSupportOpen(false);
              }}
              className="space-y-2 pt-2 border-t border-white/5"
            >
              <input
                type="text"
                placeholder="Your Name / Organization"
                required
                className="w-full bg-[#09090b] border border-white/10 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
              <textarea
                rows={2}
                placeholder="How can we help you?"
                required
                className="w-full bg-[#09090b] border border-white/10 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="w-full accent-gradient text-white text-xs font-bold py-2 rounded-lg transition-all shadow cursor-pointer"
              >
                Send Support Ticket
              </button>
            </form>

            {/* Footer Credit */}
            <div className="text-center text-[10px] text-slate-500 pt-1 border-t border-white/5 flex justify-between items-center">
              <span>Created by: <strong className="text-slate-400">Jeeva V</strong></span>
              <span className="text-[9px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.2 rounded border border-indigo-500/20 font-mono">FREE PLATFORM</span>
            </div>
          </div>
        )}

        <button
          onClick={() => setSupportOpen(!supportOpen)}
          className="accent-gradient text-white p-3 rounded-full shadow-xl shadow-indigo-500/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer font-semibold text-xs sm:text-sm"
          id="btn-support-trigger"
        >
          <MessageSquare className="w-5 h-5" />
          <span>Queries? Contact Us</span>
        </button>
      </div>
    </div>
  );
}
