export interface Freelancer {
  id: string;
  name: string;
  title: string;
  avatar: string;
  location: string;
  experience: string;
  hourlyRate: number;
  expectedSalary: string;
  rating: number;
  reviewsCount: number;
  availability: string;
  skills: string[];
  certifications: string[];
  bio: string;
  socials: {
    github?: string;
    linkedin?: string;
  };
  matchingScore?: number;
  matchedSkills?: string[];
  matchReason?: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: string;
  rate: string;
  budget: string;
  skills: string[];
  description: string;
  proposals: number;
  postedAt: string;
}

export interface Company {
  name: string;
  logo: string;
  domain: string;
  size: string;
  rating: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model" | "system";
  content: string;
  timestamp: string;
}

export type ViewMode = "explore" | "ai-workspace" | "dashboards" | "about";

export type DashboardTab = "freelancer" | "company" | "recruiter" | "admin" | "mncs" | "student";

export type AIWorkspaceTool = "search" | "resume-parser" | "interview-coach" | "draft-generator" | "ai-suite-directory";

export interface TechnologyCardInfo {
  name: string;
  category: string;
  freelancersCount: number;
  companiesHiring: number;
  openJobs: number;
  averageSalary: string;
  averageRate: string;
  demandScore: number; // 1-10
  trend: "up" | "down" | "stable";
  roadmaps: string[];
}
