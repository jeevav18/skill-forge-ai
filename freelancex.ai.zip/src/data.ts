import { TechnologyCardInfo } from "./types";

export const TECH_DOMAINS = [
  {
    id: "programming",
    name: "Programming Languages",
    icon: "💻",
    technologies: ["C", "C++", "Java", "Python", "JavaScript", "TypeScript", "Go", "Rust", "PHP", "C#", "Kotlin", "Swift", "Dart", "R", "MATLAB", "Scala", "Ruby", "Bash"]
  },
  {
    id: "web",
    name: "Web Development",
    icon: "🌐",
    technologies: ["HTML5", "CSS3", "React", "Next.js", "Angular", "Vue.js", "Svelte", "Node.js", "Express.js", "NestJS", "FastAPI", "Django", "Flask", "Laravel", "Spring Boot", "Tailwind CSS", "GraphQL"]
  },
  {
    id: "crm",
    name: "CRM & Salesforce Ecosystem",
    icon: "🏢",
    technologies: [
      "Salesforce LWC", "Apex Programming", "Salesforce Flows", "Einstein AI / Agentforce", "Sales Cloud", "Service Cloud", 
      "MuleSoft Integration", "Copado / Gearset", "HubSpot CRM", "Microsoft Dynamics 365", "Zoho CRM", "SAP CRM", "ServiceNow", "Odoo CRM"
    ]
  },
  {
    id: "ai",
    name: "Artificial Intelligence",
    icon: "🤖",
    technologies: ["Machine Learning", "Deep Learning", "Computer Vision", "NLP", "Generative AI", "LLMs", "Prompt Engineering", "AI Agents", "LangChain", "Vector Databases", "Explainable AI"]
  },
  {
    id: "cloud",
    name: "Cloud & DevOps",
    icon: "☁",
    technologies: ["AWS", "Microsoft Azure", "Google Cloud Platform", "Cloudflare", "Docker", "Kubernetes", "Terraform", "GitHub Actions", "Nginx", "Prometheus", "Grafana", "Kafka"]
  },
  {
    id: "data",
    name: "Data Science & Analytics",
    icon: "📊",
    technologies: ["PostgreSQL", "MySQL", "MongoDB", "Redis", "Snowflake", "BigQuery", "Apache Spark", "Data Engineering", "Data Warehousing", "Power BI", "Tableau"]
  },
  {
    id: "security",
    name: "Cyber Security",
    icon: "🔐",
    technologies: ["Ethical Hacking", "Penetration Testing", "Network Security", "Cloud Security", "SOC", "SIEM", "Identity Management", "Secure Coding", "Vulnerability Assessment"]
  },
  {
    id: "blockchain",
    name: "Blockchain & Web3",
    icon: "⛓",
    technologies: ["Solidity", "Rust", "Ethereum", "Polygon", "Solana", "Smart Contracts", "DeFi", "DAOs", "Cryptocurrency Wallets", "Web3 Applications"]
  },
  {
    id: "embedded",
    name: "Embedded Systems & IoT",
    icon: "⚡",
    technologies: ["Embedded C", "Embedded Linux", "RTOS", "Firmware", "ARM", "ESP32", "Arduino", "MQTT", "BLE", "LoRaWAN", "Sensor Integration"]
  },
  {
    id: "electronics",
    name: "Electronics & VLSI",
    icon: "🔌",
    technologies: ["Analog Electronics", "Digital Electronics", "PCB Design", "FPGA Development", "RTL Design", "Verilog", "SystemVerilog", "VHDL", "DFT", "Semiconductor"]
  },
  {
    id: "robotics",
    name: "Robotics & Automation",
    icon: "🤖",
    technologies: ["Robotics", "ROS", "ROS2", "PLC", "SCADA", "Mechatronics", "Autonomous Systems", "Drone Development"]
  },
  {
    id: "game",
    name: "Game Dev & AR/VR",
    icon: "🎮",
    technologies: ["Unity", "Unreal Engine", "Godot", "Multiplayer Games", "Augmented Reality", "Virtual Reality", "Mixed Reality", "Apple Vision Pro", "Meta Quest", "OpenXR"]
  },
  {
    id: "design",
    name: "UI/UX & Creative Design",
    icon: "🎨",
    technologies: ["Figma", "Adobe XD", "Sketch", "Photoshop", "Illustrator", "Wireframing", "Prototyping", "Logo Design", "Motion Graphics", "3D Animation", "Video Editing"]
  }
];

export const TECHNOLOGY_CARDS: TechnologyCardInfo[] = [
  {
    name: "Salesforce LWC",
    category: "CRM Platforms",
    freelancersCount: 24500,
    companiesHiring: 1420,
    openJobs: 310,
    averageSalary: "₹2,200,000/yr",
    averageRate: "$75/hr",
    demandScore: 9.2,
    trend: "up",
    roadmaps: ["LWC Basics", "Lightning Message Service", "Apex Integration", "Experience Cloud Deployments", "Salesforce DX CLI Workflow"]
  },
  {
    name: "Apex Programming",
    category: "CRM Platforms",
    freelancersCount: 29800,
    companiesHiring: 1850,
    openJobs: 420,
    averageSalary: "₹2,400,000/yr",
    averageRate: "$80/hr",
    demandScore: 9.4,
    trend: "up",
    roadmaps: ["Apex syntax & SOQL/SOSL", "Trigger Frameworks", "Batch Apex & Queueables", "Apex REST/SOAP Integration", "Apex Mock Testing & Optimizations"]
  },
  {
    name: "React & Next.js",
    category: "Web Development",
    freelancersCount: 154000,
    companiesHiring: 8900,
    openJobs: 2450,
    averageSalary: "₹1,600,000/yr",
    averageRate: "$55/hr",
    demandScore: 9.7,
    trend: "up",
    roadmaps: ["React state & hooks", "Vite build pipeline", "Next.js App Router (Server components)", "Tailwind Styling Patterns", "Dynamic Client-Side Caching"]
  },
  {
    name: "Generative AI / LLMs",
    category: "Artificial Intelligence",
    freelancersCount: 12500,
    companiesHiring: 2100,
    openJobs: 850,
    averageSalary: "$160,000/yr",
    averageRate: "$110/hr",
    demandScore: 9.8,
    trend: "up",
    roadmaps: ["Python & PyTorch basics", "Prompt Engineering & Structured Outputs", "Vector DBs (Milvus, Pinecone, pgvector)", "Retrieval Augmented Generation (RAG)", "Agentic workflows & Tool-calling"]
  },
  {
    name: "Agentforce & Einstein AI",
    category: "CRM Platforms",
    freelancersCount: 3200,
    companiesHiring: 680,
    openJobs: 195,
    averageSalary: "₹2,800,000/yr",
    averageRate: "$105/hr",
    demandScore: 9.5,
    trend: "up",
    roadmaps: ["Einstein Co-pilot foundation", "Prompt Builder setup", "Agentforce Agent configurations", "Autonomous customer routing", "Data Cloud Unified Profile Setup"]
  },
  {
    name: "MuleSoft Integration",
    category: "CRM Platforms",
    freelancersCount: 18400,
    companiesHiring: 950,
    openJobs: 240,
    averageSalary: "₹2,100,000/yr",
    averageRate: "$85/hr",
    demandScore: 8.9,
    trend: "stable",
    roadmaps: ["AnyPoint Studio Design", "DataWeave Language Mapping", "Mule Flows & Error Handling", "OAuth 2.0 and API Gateways", "Salesforce Connector Integrations"]
  },
  {
    name: "Solidity & Rust Web3",
    category: "Blockchain & Web3",
    freelancersCount: 19800,
    companiesHiring: 740,
    openJobs: 180,
    averageSalary: "$150,000/yr",
    averageRate: "$95/hr",
    demandScore: 8.5,
    trend: "stable",
    roadmaps: ["Ethereum Blockchain structure", "Solidity syntax & Gas optimizations", "ERC20/ERC721 Standards", "Rust and Solana programming", "Smart Contract Auditing Techniques"]
  },
  {
    name: "Kubernetes Platform",
    category: "Cloud & DevOps",
    freelancersCount: 42000,
    companiesHiring: 3400,
    openJobs: 980,
    averageSalary: "$135,000/yr",
    averageRate: "$85/hr",
    demandScore: 9.1,
    trend: "up",
    roadmaps: ["Docker Containerization", "Kubernetes Pods & Deployments", "Helm package management", "CI/CD Automations (GitHub Actions, GitLab)", "Service Mesh (Istio) & Observability"]
  }
];

export const SALESFORCE_CERTIFICATIONS = [
  { name: "Salesforce Certified Administrator", difficulty: "Beginner", time: "2-4 weeks", code: "ADM-201" },
  { name: "Platform App Builder", difficulty: "Intermediate", time: "4-6 weeks", code: "PAB" },
  { name: "Platform Developer I (PDI)", difficulty: "Intermediate", time: "4-8 weeks", code: "PD1" },
  { name: "Platform Developer II (PDII)", difficulty: "Advanced", time: "8-12 weeks", code: "PD2" },
  { name: "Data Cloud Consultant", difficulty: "Advanced", time: "4-8 weeks", code: "DCC" },
  { name: "AI Specialist", difficulty: "Advanced", time: "6-8 weeks", code: "AIS" },
  { name: "Certified Technical Architect (CTA)", difficulty: "Expert", time: "1-2 years", code: "CTA" }
];

export const MOCK_CHALLENGES = [
  { id: "c-1", title: "Apex Trigger Refactoring Challenge", reward: "$500 + Badge", difficulty: "Medium", participants: 142 },
  { id: "c-2", title: "LWC Reusable Datatable with Row-Level Actions", reward: "$350 + Profile Feature", difficulty: "Easy", participants: 254 },
  { id: "c-3", title: "Secure Agentforce Customer Routing Agent", reward: "$1,200 + Interview Fasttrack", difficulty: "Hard", participants: 83 }
];
